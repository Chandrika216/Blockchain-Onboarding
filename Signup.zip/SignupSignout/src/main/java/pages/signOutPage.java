package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class signOutPage {
	    private WebDriver driver;
	    private By signOutButton = By.xpath("//button[contains(text(), 'Sign Out')]");
	    public void SignOutPage(WebDriver driver) {
	        this.driver = driver;
	    }

	    public void signOut() {
	        driver.findElement(signOutButton).click();
	    }
	}
