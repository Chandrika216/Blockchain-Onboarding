package pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
public class singUpPage {
	protected WebDriver driver;
	private By getstarred = By.xpath("//button[text()='Get Started']");
	private By emailField = By.xpath("//body/div[@id='root']/div[@class='App']/main/div/div[1]");
    private By passwordField = By.xpath("//div[@class='App']//div//div[2]");
    private By confirmpassword = By.xpath("//input[@id='outlined-basic']");
    private By link = By.xpath("//button[contains(@class, 'signin-alt-button')]");
	

    public singUpPage(WebDriver driver) {
        this.driver=driver;
    }

    public void signUp(String email, String password,String password1) {
    	driver.findElement(getstarred).click();
        driver.findElement(emailField).sendKeys(email);
        driver.findElement(passwordField).sendKeys(password);
        driver.findElement(confirmpassword).sendKeys(password1);
        driver.findElement(link).click();
        
    }
}