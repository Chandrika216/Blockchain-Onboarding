package pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
public class signInPage {
	protected WebDriver driver;
	private By emailField = By.xpath("//body/div[@id='root']/div[@class='App']/main/div/div[1]");
    private By passwordField = By.xpath("//div[@class='App']//div//div[2]");
    private By signUpButton = By.xpath("//button[normalize-space()='Sign In']");

    public signInPage(WebDriver driver) {
        this.driver=driver;
    }

    public void signIn(String email, String password) {
        driver.findElement(emailField).sendKeys(email);
        driver.findElement(passwordField).sendKeys(password);
        driver.findElement(signUpButton).click();
    }
}
