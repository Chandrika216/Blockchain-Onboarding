package tests;
import pages.signOutPage;
import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class signOuTest  {
	 private WebDriver driver;
	 
	    @Test
		public void testSignOut() {
	  
	    	// No-argument constructor
	    	
	    	signOuTest signOutPage = new signOuTest();
	        signOutPage.testSignOut();
	        Assert.assertTrue(driver.getCurrentUrl().contains("login"));
	        driver.quit();
	 }
}
	        