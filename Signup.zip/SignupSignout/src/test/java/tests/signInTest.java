package tests;

import pages.signInPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class signInTest {
    private WebDriver driver;
    private signInPage page;

    public signInTest() {
        // No-argument constructor
    }

    @BeforeClass
    public void setUp() {
        // Initialize WebDriver and signInPage here
        WebDriver driver = new ChromeDriver();
        page = new signInPage(driver);
    }

    @Test
    public void testSignIn() throws InterruptedException {
    	driver.get("https://xaltsocnportal.web.app/signin");
        page.signIn("Validemail.com", "");
        // Add assertions to verify successful sign-in
        Assert.assertTrue(driver.getCurrentUrl().contains("dashboard")); // Adjust the URL part as needed
    }

    @AfterClass
    public void tearDown() {
        // Close the browser
        if (driver != null) {
            driver.quit();
        }
    }
}
