package tests;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.signInPage;


public class signUpTest {
	 private WebDriver driver;
	 @BeforeClass
	    public void setUp() {
	        // Initialize WebDriver and signInPage here
	        WebDriver driver = new ChromeDriver();
	        new signInPage(driver);
	 }
	@Test
    public void testSignUp() {
		 driver.get("https://xaltsocnportal.web.app/");
		 signUpTest signUpPage = new signUpTest();
		 signUpPage.signUp("valid@example.com", "ValidPassword123", "ValidPassword123");
		 
	Assert.assertTrue(driver.getCurrentUrl().contains("confirmation"));
}

	private void signUp(String string, String string2, String string3) {
		// TODO Auto-generated method stub
		
	}
		
}
